import "./App.css";
import React from "react";
import { Switch, BrowserRouter as Router, Route } from "react-router-dom";
import Bavaria from "./components/Bavaria";

function App() {
  return (
    <Router>
      <Switch>
        <Route path="/:path(|bavaria)">
          <Bavaria {...bavariaData} />
        </Route>
      </Switch>
    </Router>
  );
}

export default App;
const bavariaData = {
    iconMedicines: "/img/---icon--medicines-@2x.png",
    bavaria: "Bavaria",
    patientList: "Patient List",
    navbarLinkPlace1: "Name",
    navbarLinkResults: "Results",
    navbarLinkPlace2: "Date",
    navbarLinkPlacebo: "Placebo",
    shyamKhanna: "Shyam Khanna",
    text1: "01/27",
    name1: "Jean Lee Un",
    text2: "01/27",
    name2: "Clara Brook",
    text3: "01/27",
    title: "Send Drugs",
};

