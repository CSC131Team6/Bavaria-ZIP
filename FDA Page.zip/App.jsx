import "./App.css";
import React from "react";
import { Switch, BrowserRouter as Router, Route } from "react-router-dom";
import FDA from "./components/FDA";

function App() {
  return (
    <Router>
      <Switch>
        <Route path="/:path(|fda)">
          <FDA {...fDAData} />
        </Route>
      </Switch>
    </Router>
  );
}

export default App;
const fDAData = {
    image1: "/img/image-1@2x.png",
    spanText1: <React.Fragment>U.S FOOD &amp; DRUG<br /></React.Fragment>,
    spanText2: "Administration",
    patientList: "Patient List",
    place1: "Name",
    results: "Results",
    place2: "Date",
    placebo: "Placebo",
    shyamKhanna: "Shyam Khanna",
    text1: "01/27",
    text2: "01/27",
    name1: "Jean Lee Un",
    name2: "Clara Brook",
    text3: "01/27",
};

