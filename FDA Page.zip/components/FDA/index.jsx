import React from "react";
import "./FDA.css";

function FDA(props) {
  const {
    image1,
    spanText1,
    spanText2,
    patientList,
    place1,
    results,
    place2,
    placebo,
    shyamKhanna,
    text1,
    text2,
    name1,
    name2,
    text3,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="fda screen">
        <div className="overlap-group1">
          <img className="image-1" src={image1} alt="image 1" />
          <h1 className="us-food-drug-administration doppioone-normal-gallery-32px">
            <span className="doppioone-normal-gallery-32px">{spanText1}</span>
            <span className="span1">{spanText2}</span>
          </h1>
        </div>
        <div className="overlap-group">
          <div className="rectangle-377"></div>
          <div className="rectangle-357"></div>
          <div className="rectangle-358"></div>
          <div className="rectangle-359"></div>
          <div className="patient-list valign-text-middle">{patientList}</div>
          <div className="place valign-text-middle poppins-medium-gray-14px">{place1}</div>
          <div className="results valign-text-middle poppins-medium-gray-14px">{results}</div>
          <div className="place-1 valign-text-middle poppins-medium-gray-14px">{place2}</div>
          <div className="placebo valign-text-middle poppins-medium-gray-14px">{placebo}</div>
          <div className="shyam-khanna valign-text-middle poppins-medium-jacarta-14px">{shyamKhanna}</div>
          <div className="text-1 valign-text-middle poppins-medium-killarney-14px">{text1}</div>
          <img className="vector" src="/img/vector.svg" alt="Vector" />
          <img className="vector-1" src="/img/vector.svg" alt="Vector" />
          <div className="text-2 valign-text-middle poppins-medium-killarney-14px">{text2}</div>
          <div className="name valign-text-middle poppins-medium-jacarta-14px">{name1}</div>
          <div className="name-1 valign-text-middle poppins-medium-jacarta-14px">{name2}</div>
          <div className="text-3 valign-text-middle poppins-medium-killarney-14px">{text3}</div>
          <img className="vector-2" src="/img/vector.svg" alt="Vector" />
        </div>
      </div>
    </div>
  );
}

export default FDA;
