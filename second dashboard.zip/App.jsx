import "./App.css";
import React from "react";
import { Switch, BrowserRouter as Router, Route } from "react-router-dom";
import DoctorDashboard from "./components/DoctorDashboard";

class App extends React.Component {
  render() {
    return (
      <Router>
        <Switch>
          <Route path="/:path(|doctor-dashboard)">
            <DoctorDashboard {...doctorDashboardData} />
          </Route>
        </Switch>
      </Router>
    );
  }
}

export default App;
const profile1Data = {
    pagetitle: "Profile",
};

const profile2Data = {
    pagetitle: "Log out",
    className: "pages-item",
};

const largeInputData = {
    search: "Search",
};

const doctorDashboardData = {
    iconHospital: "/img/---icon--hospital-@2x.png",
    pagetitle1: "Dashboard",
    pagetitle2: "Patient List",
    pagetitle3: "Tables",
    pagetitle4: "Articles",
    title: "Welcome Doctor",
    group155: "/img/group-155@2x.png",
    number: "100",
    patientsOnTrial: "Patients On Trial",
    seeMore: "See more",
    editInfo: "Edit Info",
    shyamKhanna: "Shyam Khanna",
    name1: "Jean Lee Un",
    name2: "Clara Brook",
    text1: "01/27",
    text2: "01/27",
    text3: "01/27",
    place1: "Name",
    dosage: "Dosage",
    place2: "Date",
    eligibility: "Eligibility",
    patientList: "Patient List",
    profile1Props: profile1Data,
    profile2Props: profile2Data,
    largeInputProps: largeInputData,
};

