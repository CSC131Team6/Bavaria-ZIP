import React from "react";
import Profile from "../Profile";
import LargeInput from "../LargeInput";
import "./DoctorDashboard.css";

class DoctorDashboard extends React.Component {
  render() {
    const {
      iconHospital,
      pagetitle1,
      pagetitle2,
      pagetitle3,
      pagetitle4,
      title,
      group155,
      number,
      patientsOnTrial,
      seeMore,
      editInfo,
      shyamKhanna,
      name1,
      name2,
      text1,
      text2,
      text3,
      place1,
      dosage,
      place2,
      eligibility,
      patientList,
      profile1Props,
      profile2Props,
      largeInputProps,
    } = this.props;

    return (
      <div className="container-center-horizontal">
        <div className="doctor-dashboard screen">
          <div className="overlap-group2">
            <div className="overlap-group5">
              <img className="icon-hospital" src={iconHospital} alt="icon &#34;Hospital&#34;" />
            </div>
            <div className="pages">
              <div className="dashboard">
                <img className="icon-home" src="/img/icon-4.svg" alt="icon-home" />
                <div className="pagetitle">{pagetitle1}</div>
                <div className="active"></div>
              </div>
              <div className="patient-list">
                <div className="vector-container">
                  <img className="vector" src="/img/vector-3.svg" alt="Vector" />
                  <img className="vector-1" src="/img/vector-4.svg" alt="Vector" />
                  <img className="vector-2" src="/img/vector-5.svg" alt="Vector" />
                </div>
                <div className="pagetitle-1 poppins-medium-pumice-16px">{pagetitle2}</div>
              </div>
              <div className="tables">
                <img className="icon" src="/img/icon-3.svg" alt="Icon" />
                <div className="pagetitle-2 poppins-medium-pumice-16px">{pagetitle3}</div>
              </div>
              <div className="kanban">
                <img className="icon-1" src="/img/icon-2.svg" alt="Icon" />
                <div className="pagetitle-3 poppins-medium-pumice-16px">{pagetitle4}</div>
              </div>
              <Profile pagetitle={profile1Props.pagetitle} />
              <Profile pagetitle={profile2Props.pagetitle} className={profile2Props.className} />
            </div>
          </div>
          <div className="flex-col">
            <h1 className="title valign-text-middle">{title}</h1>
            <div className="overlap-group4">
              <img className="group-155" src={group155} alt="Group 155" />
              <div className="flex-col-1">
                <div className="number valign-text-middle">{number}</div>
                <div className="patients-on-trial valign-text-middle poppins-medium-ship-gray-14px">
                  {patientsOnTrial}
                </div>
              </div>
            </div>
            <div className="overlap-group1">
              <div className="overlap-group">
                <div className="see-more valign-text-middle poppins-medium-ship-gray-14px">{seeMore}</div>
                <div className="edit-info valign-text-middle poppins-medium-gray-14px">{editInfo}</div>
              </div>
              <div className="rectangle-357"></div>
              <div className="rectangle-358"></div>
              <div className="rectangle-359"></div>
              <div className="shyam-khanna valign-text-middle poppins-medium-killarney-14px">{shyamKhanna}</div>
              <div className="name valign-text-middle poppins-medium-killarney-14px">{name1}</div>
              <div className="name-1 valign-text-middle poppins-medium-killarney-14px">{name2}</div>
              <div className="text-1 valign-text-middle poppins-medium-killarney-14px">{text1}</div>
              <div className="text-2 valign-text-middle poppins-medium-killarney-14px">{text2}</div>
              <div className="text-3 valign-text-middle poppins-medium-killarney-14px">{text3}</div>
              <div className="place valign-text-middle poppins-medium-gray-14px">{place1}</div>
              <div className="dosage valign-text-middle poppins-medium-gray-14px">{dosage}</div>
              <div className="place-1 valign-text-middle poppins-medium-gray-14px">{place2}</div>
              <div className="eligibility valign-text-middle poppins-medium-gray-14px">{eligibility}</div>
              <img className="vector-3" src="/img/vector.svg" alt="Vector" />
              <img className="vector-4" src="/img/vector.svg" alt="Vector" />
              <img className="vector-5" src="/img/vector.svg" alt="Vector" />
              <div className="patient-list-1 valign-text-middle">{patientList}</div>
            </div>
          </div>
          <div className="overlap-group3">
            <LargeInput search={largeInputProps.search} />
            <img className="ation" src="/img/notifications-none.svg" alt="notifications_none" />
            <img className="moon-solid-1" src="/img/moon-solid-1.svg" alt="moon-solid 1" />
            <img className="ation" src="/img/info-outline.svg" alt="icon-information" />
          </div>
        </div>
      </div>
    );
  }
}

export default DoctorDashboard;
