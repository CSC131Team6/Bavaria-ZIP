import React from "react";
import "./LargeInput.css";

class LargeInput extends React.Component {
  render() {
    const { search } = this.props;

    return (
      <div className="large-input">
        <div className="overlap-group-1">
          <div className="ellipse-6"></div>
          <img className="line-1" src="/img/line-1.svg" alt="Line 1" />
        </div>
        <div className="search">{search}</div>
      </div>
    );
  }
}

export default LargeInput;
