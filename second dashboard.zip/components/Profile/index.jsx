import React from "react";
import "./Profile.css";

class Profile extends React.Component {
  render() {
    const { pagetitle, className } = this.props;

    return (
      <div className={`pages-item-1 ${className || ""}`}>
        <img className="icon-2" src="/img/icon-1.svg" alt="Icon" />
        <div className="pagetitle-4 poppins-medium-pumice-16px">{pagetitle}</div>
      </div>
    );
  }
}

export default Profile;
